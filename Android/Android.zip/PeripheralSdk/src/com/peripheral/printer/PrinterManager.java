/**
 * 
 */
package com.peripheral.printer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.util.Log;

import com.peripheral.printer.adapter.PrinterAdapterBase;
import com.peripheral.printer.adapter.PrinterAdapterNet;
import com.peripheral.printer.adapter.PrinterAdapterSerial;
import com.peripheral.printer.adapter.PrinterAdapterUsb;
import com.peripheral.printer.api.IPrinterCallBack;
import com.peripheral.printer.api.PrinterParam;
import com.peripheral.printer.api.PrinterSearchEntry;
import com.peripheral.printer.api.PrinterUtils;
import com.raimy.utils.CustMutex;
import com.raimy.utils.LogHelper;

/**
 * @author raimy
 *
 */
public class PrinterManager implements IInnerOpCallBack{
	private static PrinterManager sTheMe;
	private List<IPrinterCallBack> mCallBacks;
	private List<PrinterEntry> mPrinters;
	private List<PrinterSearchEntry> mSearchEntries;
	private List<PrinterParam> mHandleOps;
	private Thread mHandlerThread;
	private Context mContext;
	private CustMutex mMutex;
	private CustMutex mPrintersMutex;
	private CustMutex mSearchMutex;
	private CustMutex mHandleMutex;
	
	/**回调类型
	 * @author raimy
	 *
	 */
	public class PrinterEntry{
		public int nCommuType;//通信类型
		public String strName;//名称
		public String strIdent;//唯一标识
		//public CommuBase commu;
		public PrinterAdapterBase adapter;
		
		public PrinterEntry(){
			
		}
		
		public PrinterEntry(PrinterParam param, PrinterAdapterBase adapter){
			nCommuType = param.mCommuType;
			strName = param.mName;
			strIdent = param.mIdent;
			this.adapter = adapter;
		}
	}
	
	private PrinterManager(){
	}
	
	public static PrinterManager GetInstance(){
		if (null==sTheMe){
			synchronized (PrinterManager.class) {
				sTheMe= new PrinterManager();
			}
		}
		return sTheMe;
	}
	
	
	
	public void Init(Context context){
		mContext = context;
		mCallBacks = new ArrayList<IPrinterCallBack>();
		mPrinters = new ArrayList<PrinterEntry>();
		mSearchEntries = new ArrayList<PrinterSearchEntry>();
		mHandleOps = new ArrayList<PrinterParam>();
		mMutex = new CustMutex();
		mPrintersMutex = new CustMutex();
		mSearchMutex = new CustMutex();
		mHandleMutex = new CustMutex();
		
		mHandlerThread = new HandleThread();
		mHandlerThread.start();
	}
	
	public void UnInit(){
		
	}
	
	public void RegistCallBack(IPrinterCallBack callBack){
		mMutex.lock();
		mCallBacks.add(callBack);
		mMutex.unlock();
	}
	
	public void UnRegistCallBack(IPrinterCallBack callBack){
		mMutex.lock();
		Iterator<IPrinterCallBack> it = mCallBacks.iterator();
		IPrinterCallBack tmpCallBack;
		while(it.hasNext()){
			tmpCallBack = it.next();
		    if(tmpCallBack == callBack){
		        it.remove();
		        break;
		    }
		}
		mMutex.unlock();
	}
	
	
	private PrinterParam GetOp(){
		PrinterParam param = null;
		mHandleMutex.lock();
		if(mHandleOps.size()>0){
			param = new PrinterParam(mHandleOps.get(0));
			mHandleOps.remove(0);	
		}
		mHandleMutex.unlock();
		return param;
	}
	
	private void AddOp(PrinterParam param){
		mHandleMutex.lock();
		mHandleOps.add(param);
		mHandleMutex.unlock();
	}
	
	class HandleThread extends Thread{
		private Boolean isInterrupted = false;
		@Override
		public void run() {
			// TODO Auto-generated method stub
			super.run();
			Log.i(getClass().getSimpleName(), "HandleThread------Run");
			PrinterParam param=null;
			while (!isInterrupted) {
				
				param = GetOp();
				if (param!=null) {
					HandleOp(param);
				}
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Log.i(getClass().getSimpleName(), "HandleThread------exit");
			
		}
		
		@Override
		public void interrupt() {
			// TODO Auto-generated method stub
			isInterrupted = true;
			super.interrupt();
		}
		
	}
	
	private void HandleOp(PrinterParam param){
		switch (param.mOpType) {
		case PrinterUtils.OpType_Connect:
			DoOpConnect(param); 
			break;
		case PrinterUtils.OpType_PrintBmp:
			DoOpPrintBmp(param);
			break;			
		case PrinterUtils.OpType_Search:
			DoOpSearch(param);
			break;	
		case PrinterUtils.OpType_GetInfo:
			DoOpGetInfo(param);
			break;	
		default:
			break;
		}
	}
	
	public void Operate(PrinterParam param){
		AddOp(param);
	}
	
	private void DoOpConnect(PrinterParam param){
		PrinterEntry entry = AddPrinter(param);
		entry.adapter.Connect(param);	
	}
	
	private void DoOpDisConnect(PrinterParam param){
		RemovePrinter(param);
	}
	
	private void DoOpPrintBmp(PrinterParam param){
		PrinterEntry entry = AddPrinter(param);
		entry.adapter.PrintBmp(param);
	}
	
	
	private PrinterAdapterBase GetPrinterAdapter(int commType){
		PrinterAdapterBase adapter=null;
		if (commType == PrinterUtils.COMMU_SERIAL) {
			adapter = new PrinterAdapterSerial(mContext,commType, this);
		}else if (commType == PrinterUtils.COMMU_USB) {
			adapter = new PrinterAdapterUsb(mContext, commType,this);
		}else if (commType == PrinterUtils.COMMU_NET) {
			adapter = new PrinterAdapterNet(mContext,commType, this);
		}
		return adapter;
	}
	
	
	private void DoOpSearch(PrinterParam param){
			// TODO Auto-generated method stub
			
			if (!IsAllSearched()) {
				int nCommuType = GetSearchingType();
				PrinterParam param2 = new PrinterParam(nCommuType, "", 
						PrinterUtils.OpType_Search, PrinterUtils.Result_Fail, PrinterUtils.Err_Searching);
				DoCallBacks(param2);
				return;
			}
		
		    PrinterAdapterBase adapterBase = null;
		    PrinterEntry entry = AddPrinter(param);
		    adapterBase = entry.adapter;
		    
		    mSearchMutex.lock();
		    mSearchEntries.clear();
			List<PrinterSearchEntry> strDevices = adapterBase.GetDeviceList();
			for (int i = 0; i < strDevices.size(); i++) {
				PrinterSearchEntry searchEntry = new PrinterSearchEntry(param.mCommuType);
				searchEntry.mIdent = strDevices.get(i).mIdent;
				mSearchEntries.add(searchEntry);
				break;//test
			}
			
			SearchPrinterThread searchPrinterThread=null;
			PrinterParam param1=null;
			
			for (int i = 0; i < mSearchEntries.size(); i++) {
				param1 = new PrinterParam();
				param1.mCommuType = param.mCommuType;
				param1.mIdent = mSearchEntries.get(i).mIdent;
				param1.mStrParam1 = mSearchEntries.get(i).mIdent;
				
				if (param.mCommuType == PrinterUtils.COMMU_SERIAL) {
					param1.mIntParam1 = 115200;
				}else if (param.mCommuType == PrinterUtils.COMMU_USB) {
					param1.mIntParam1 = mSearchEntries.get(i).VendorID;
					param1.mIntParam2 = mSearchEntries.get(i).ProductID;
				}
				
				
				adapterBase = GetPrinterAdapter(param1.mCommuType);
				searchPrinterThread = new SearchPrinterThread(mContext, this, adapterBase, param1);
				searchPrinterThread.start();
			}
			mSearchMutex.unlock();
			
			if (searchPrinterThread == null) {
				PrinterParam pra = new PrinterParam(param);
				pra.mOutResult = PrinterUtils.Result_Fail;
				pra.mOutErrCode = PrinterUtils.Err_No_Interface;
				DoCallBacks(pra);
			}
	}
	
	private void DoOpGetInfo(PrinterParam param){
		PrinterAdapterBase adapterBase = null;
	    PrinterEntry entry = AddPrinter(param);
	    adapterBase = entry.adapter;
	    
	    String strDataString = "123456789\n";
	    
	    adapterBase.Write(strDataString);
//	    byte[] data = new byte[3];
//	    data[0] = (byte)10;
//	    data[1] = (byte)4;
//	    data[2] = (byte)1;
//	    
//	    adapterBase.Write(data);
//	    try {
//			Thread.sleep(500);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	    
//    	adapterBase.Read();
	    
	    
	}
	
	private Boolean IsAllSearched(){
		Boolean bRet=true;
		mSearchMutex.lock();
		for (int i = 0; i < mSearchEntries.size(); i++) {
			bRet = mSearchEntries.get(i).mHasDev!=2;
			if (bRet==false) {
				break;
			}
		}
		mSearchMutex.unlock();
		return bRet;
	}
	
	private int GetSearchingType(){
		int nType=0;
		mSearchMutex.lock();
		if (mSearchEntries.size()>0) {
			nType = mSearchEntries.get(0).mCommuType;
		}
		mSearchMutex.unlock();
		
		return nType;
	}
	
	private void SetSearched(PrinterParam Param){
		mSearchMutex.lock();
		for (int i = 0; i < mSearchEntries.size(); i++) {
			if (Param.mIdent == mSearchEntries.get(i).mIdent) {
				mSearchEntries.get(i).mHasDev = (byte)(Param.mOutResult==PrinterUtils.Result_Suc?1:0);
				break;
			}
		}
		mSearchMutex.unlock();
	}
	
	
	private void DoCallBacks(PrinterParam param){
		mMutex.lock();
		for (int i = 0; i < mCallBacks.size(); i++) {
			IPrinterCallBack callBack = mCallBacks.get(i);
			if (null!=callBack) {
				callBack.OnCallBackFunc(param);
			}
		}
		mMutex.unlock();
	}
	
	private PrinterEntry GetPrinter(PrinterParam param){
		PrinterEntry ret = null;
		mPrintersMutex.lock();
		PrinterEntry entry; 
		for (int i = 0; i < mPrinters.size(); i++) {
			entry = mPrinters.get(i);
			if (entry.strIdent == param.mIdent) {
				ret = entry;
				break;
			}
		}
		mPrintersMutex.unlock();
		return ret;
	}
	
	private PrinterEntry AddPrinter(PrinterParam param){
		PrinterAdapterBase adapter=null;
		PrinterEntry retEntry=null;
		
		retEntry = GetPrinter(param);
		if (retEntry == null) {
			adapter = GetPrinterAdapter(param.mCommuType);
			
			if (adapter!=null) {
					retEntry = new PrinterEntry(param, adapter);
					mPrintersMutex.lock();
					mPrinters.add(retEntry);
					mPrintersMutex.unlock();
					LogHelper.logI(getClass().getSimpleName(), "---connect sucess then add");
			}
		}else {
			LogHelper.logI(getClass().getSimpleName(), "AddPrinter ---- allready exist: "+param.mIdent);
		}
		return retEntry;
		
	}
	
	
	
	private void RemovePrinter(PrinterParam param){
		mPrintersMutex.lock();
		Iterator<PrinterEntry> it = mPrinters.iterator();
		PrinterEntry entry;
		while(it.hasNext()){
			entry = it.next();
		    if(param.mIdent == entry.strIdent){
		    	if (entry.adapter != null) {
		    		entry.adapter.DisConnect(param);
			    	entry.adapter = null;
				}
		        it.remove();
		    }
		}
		mPrintersMutex.unlock();
	}

	@Override
	public void OnCallBackFunc(PrinterParam Param) {
		// TODO Auto-generated method stub
		if (Param.mOpType == PrinterUtils.OpType_Search) {
			SetSearched(Param);
			if (IsAllSearched()) {
				PrinterParam Param1 = new PrinterParam();
				Param1.mCommuType = Param.mCommuType;
				Param1.mOpType = Param.mOpType;
				
				DoCallBacks(Param1);
			}
		}else {
			DoCallBacks(Param);
		}
	}
	
	public List<PrinterSearchEntry> GetSearchList(PrinterParam param){
		List<PrinterSearchEntry> retlist = new ArrayList<PrinterSearchEntry>();
		PrinterSearchEntry entry;
		mSearchMutex.lock();
		for (int i = 0; i < mSearchEntries.size(); i++) {
			entry = mSearchEntries.get(i);
			if (entry.mHasDev==1) {
				retlist.add(entry);
			}
		}
		mSearchMutex.unlock();
		return retlist;
	}
	
	
}
