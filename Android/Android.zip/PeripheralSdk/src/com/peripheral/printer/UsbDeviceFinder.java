/**
 * 
 */
package com.peripheral.printer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.peripheral.printer.api.PrinterSearchEntry;
import com.peripheral.printer.api.PrinterUtils;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;

/**
 * @author raimy
 *
 */
public class UsbDeviceFinder {
	private UsbManager mUsbManager;
	private Context mContext;
	
	public UsbDeviceFinder(Context context){
		mContext = context;
		mUsbManager = (UsbManager)mContext.getSystemService(Context.USB_SERVICE);
	}
	
	public List<PrinterSearchEntry> GetDevices(){
		List<PrinterSearchEntry> list= new ArrayList<PrinterSearchEntry>();
		
		HashMap<String, UsbDevice> devList = mUsbManager.getDeviceList();
    	Iterator<UsbDevice> devIter = devList.values().iterator();
    	while(devIter.hasNext()){
    		UsbDevice device = devIter.next();
    		PrinterSearchEntry entry = new PrinterSearchEntry(PrinterUtils.COMMU_USB);
    		entry.VendorID = device.getVendorId();
    		entry.ProductID = device.getProductId();
    		entry.mName = device.getDeviceName();
    		
    		list.add(entry);
    	}
    	return list;
	}
	
	
}
