/**
 * 
 */
package com.peripheral.printer.commu;

/**
 * @author raimy
 *
 */
public abstract class CommuBase {
	public abstract Boolean Connect();
	public abstract Boolean DisConnect();
	public abstract Boolean Write(String data);
	public abstract Boolean Write(byte[] data);
	public abstract byte[] Read();
}
