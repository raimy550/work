/**
 * 
 */
package com.peripheral.printer.commu;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;

import com.raimy.utils.LogHelper;

import android.R.string;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.database.CursorJoiner.Result;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

/**
 * @author raimy
 *
 */
public class CommuUsb extends CommuBase{
	private Context mContext;
	private UsbManager mUsbManager;
	private UsbDevice mUsbDevice;
	private UsbInterface mUsbInterface;
	private UsbDeviceConnection mUsbDeviceConnection;
	private UsbEndpoint mUsbEndpointIn;
    private UsbEndpoint mUsbEndpointOut;
    private Integer mVenderId, mProductId;
	
	
	public CommuUsb(Context context, int nVenderId, int nProductId){
		mVenderId = nVenderId;
		mProductId = nProductId;
		mContext = context;
		mUsbManager = (UsbManager)mContext.getSystemService(Context.USB_SERVICE);
		
	}
	
	/* (non-Javadoc)
	 * @see com.android.peripheralsdk.printer.CommuBase#Write(java.lang.String)
	 */
	@Override
	public Boolean Write(String data) {
		// TODO Auto-generated method stub
		Boolean bRet = false;
		byte[] byData = null;
		byData = data.getBytes(Charset.forName("GBK"));
		int nRet = mUsbDeviceConnection.bulkTransfer(mUsbEndpointOut, byData, byData.length, 0);
		if (nRet>=0) {
			LogHelper.logI(getClass().getName(), "---write sucess");
			bRet = true;
		}else{
			LogHelper.logI(getClass().getName(), "---write fail");
			bRet = false;
		}
		
		return bRet;
	}

	/* (non-Javadoc)
	 * @see com.android.peripheralsdk.printer.CommuBase#Connect()
	 */
	@Override
	public Boolean Connect() {
		// TODO Auto-generated method stub
		Boolean bRet=false;
		if (FindUsbDevice()) {
			if (mUsbManager.hasPermission(mUsbDevice)) {
					bRet = OpenDevice();
			}else{
				PendingIntent pdIntent = null;
				mUsbManager.requestPermission(mUsbDevice, pdIntent);
			}
		}
		return bRet;
	}

	/* (non-Javadoc)
	 * @see com.android.peripheralsdk.printer.CommuBase#DisConnect()
	 */
	@Override
	public Boolean DisConnect() {
		// TODO Auto-generated method stub
		mUsbDeviceConnection.close();
		mUsbDeviceConnection = null;
		return null;
	}
	
	/**
     * 分配端点，IN | OUT，即输入输出；可以通过判断
     */
	private Boolean OpenDevice() {
    	 Boolean bRet=false;
    	 int interfaceCount = mUsbDevice.getInterfaceCount();
         for (int interfaceIndex = 0; interfaceIndex < interfaceCount; interfaceIndex++) {
             UsbInterface usbInterface = mUsbDevice.getInterface(interfaceIndex);
             if ((UsbConstants.USB_CLASS_CDC_DATA != usbInterface.getInterfaceClass())
                     && (UsbConstants.USB_CLASS_COMM != usbInterface.getInterfaceClass())) {
                 continue;
             }

             for (int i = 0; i < usbInterface.getEndpointCount(); i++) {
                 UsbEndpoint ep = usbInterface.getEndpoint(i);
                 if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                     if (ep.getDirection() == UsbConstants.USB_DIR_OUT) {
                    	 mUsbEndpointIn = ep;
                     } else {
                         mUsbEndpointOut = ep;
                     }
                 }
             }
             
             if ((null == mUsbEndpointIn) || (null == mUsbEndpointOut)) {
                 mUsbEndpointIn = null;
                 mUsbEndpointOut = null;
                 mUsbInterface = null;
             } else {
                 mUsbInterface = usbInterface;
                 mUsbDeviceConnection = mUsbManager.openDevice(mUsbDevice);
                 bRet=true;
                 break;
             }
         }
         return bRet;
    }

	private Boolean FindUsbDevice(){
    	Boolean bRet = false;
    	HashMap<String, UsbDevice> devList = mUsbManager.getDeviceList();
    	Iterator<UsbDevice> devIter = devList.values().iterator();
    	while(devIter.hasNext()){
    		UsbDevice device = devIter.next();
    		if (device.getVendorId() == mVenderId && device.getProductId() == mProductId) {
    			mUsbDevice = device; 
    			bRet=true;
    			break;
    		}
    	}
    	return bRet;
    }

	@Override
	public Boolean Write(byte[] data) {
		// TODO Auto-generated method stub
		Boolean bRet = false;
		int nRet = mUsbDeviceConnection.bulkTransfer(mUsbEndpointOut, data, data.length, 0);
		if (nRet>=0) {
			LogHelper.logI(getClass().getName(), "---write sucess");
			bRet = true;
		}else{
			LogHelper.logI(getClass().getName(), "---write fail");
			bRet = false;
		}
		
		return bRet;
	}

	@Override
	public byte[] Read() {
		// TODO Auto-generated method stub
		byte[] byteRead= new byte[1024];
		byte[] byteRet = null;
		int nRet = mUsbDeviceConnection.bulkTransfer(mUsbEndpointIn, byteRead, byteRead.length, 0);
		if (nRet>=0) {
			LogHelper.logI(getClass().getName(), "---write sucess");
			byteRet = new byte[nRet];
			System.arraycopy(byteRead, 0, byteRet, 0, nRet);
		}else{
			LogHelper.logI(getClass().getName(), "---write fail");
		}
		
		return byteRet;
	}
}
