/**
 * 
 */
package com.peripheral.printer.adapter;

import java.util.List;

import android.content.Context;

import com.peripheral.printer.IInnerOpCallBack;
import com.peripheral.printer.api.PrinterParam;
import com.peripheral.printer.api.PrinterSearchEntry;
import com.peripheral.printer.commu.CommuBase;
import com.peripheral.printer.commu.CommuNet;

/**
 * @author raimy
 *
 */
public class PrinterAdapterNet extends PrinterAdapterBase{

	
	/**
	 * @param context
	 * @param callBack
	 */
	public PrinterAdapterNet(Context context, int commuType, IInnerOpCallBack callBack) {
		super(context,commuType, callBack);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Boolean ConnectImp(PrinterParam param) {
		// TODO Auto-generated method stub
		if (mCommu==null) {
			mCommu = new CommuNet(param.mStrParam1, param.mIntParam1);
		}
		return mCommu.Connect();
	}

	@Override
	public void DisConnectImp(PrinterParam param) {
		// TODO Auto-generated method stub
		if (mCommu!=null) {
			mCommu.DisConnect();
		}
	}

	@Override
	public List<PrinterSearchEntry> GetDeviceList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Write(String data) {
		// TODO Auto-generated method stub
		mCommu.Write(data);
	}

	@Override
	public byte[] Read() {
		// TODO Auto-generated method stub		
		byte[] rec;
		rec = mCommu.Read();
		if (rec!=null) {
	    	String strData = new String(rec);
	    	PrinterParam param = new PrinterParam(GetCommuType());
	    	param.mStrParam1 = strData;
			mCallBack.OnCallBackFunc(param);
		}	
		return rec;
	}

	@Override
	public void Write(byte[] data) {
		// TODO Auto-generated method stub
		mCommu.Write(data);
	}

}
