/**
 * 
 */
package com.peripheral.printer.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android_serialport_api.SerialPortFinder;

import com.peripheral.printer.IInnerOpCallBack;
import com.peripheral.printer.PrinterManager.PrinterEntry;
import com.peripheral.printer.api.PrinterParam;
import com.peripheral.printer.api.PrinterSearchEntry;
import com.peripheral.printer.api.PrinterUtils;
import com.peripheral.printer.commu.CommuBase;
import com.peripheral.printer.commu.CommuSerial;
import com.raimy.utils.CustMutex;

/**
 * @author raimy
 *
 */
public class PrinterAdapterSerial extends PrinterAdapterBase{
	private SerialPortFinder mSerialPortFinder;


	public PrinterAdapterSerial(Context context, int commuType, IInnerOpCallBack callBack) {
		// TODO Auto-generated constructor stub
		super(context,commuType,  callBack);
		mSerialPortFinder = new SerialPortFinder();
	}

	@Override
	public Boolean ConnectImp(PrinterParam param) {
		// TODO Auto-generated method stub
		if (mCommu==null) {
			mCommu = new CommuSerial(mContext, param.mStrParam1, param.mIntParam1);
		}
		return mCommu.Connect();
	}

	@Override
	public void DisConnectImp(PrinterParam param) {
		// TODO Auto-generated method stub
		if (mCommu!=null) {
			mCommu.DisConnect();
		}
	}

	@Override
	public List<PrinterSearchEntry> GetDeviceList() {
		// TODO Auto-generated method stub
		List<PrinterSearchEntry> list = new ArrayList<PrinterSearchEntry>();
		
		String[] paths = mSerialPortFinder.getAllDevicesPath();
		for (int i = 0; i < paths.length; i++) {
			PrinterSearchEntry entry = new PrinterSearchEntry(PrinterUtils.COMMU_SERIAL);
			entry.mIdent = paths[i];
			list.add(entry);
		}
		return list;
	}

	@Override
	public void Write(String data) {
		// TODO Auto-generated method stub
		mCommu.Write(data);
		
	}

	@Override
	public byte[] Read() {
		// TODO Auto-generated method stub
		return mCommu.Read();
	}

	@Override
	public void Write(byte[] data) {
		// TODO Auto-generated method stub
		
	}

}
