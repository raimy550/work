/**
 * 
 */
package com.peripheral.printer.api;

/**
 * @author raimy
 *
 */
public interface IPrinterCallBack {
	public void OnCallBackFunc(PrinterParam Param);
}
