/**
 * 
 */
package com.peripheral.printer;

import com.peripheral.printer.api.PrinterParam;

/**
 * @author raimy
 *
 */
public interface IInnerOpCallBack {
	public void OnCallBackFunc(PrinterParam Param);
}
