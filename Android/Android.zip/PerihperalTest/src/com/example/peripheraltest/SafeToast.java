package com.example.peripheraltest;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.widget.Toast;

public class SafeToast {
	private Handler mToastHandler;
	private Context mContext;
	
	public SafeToast(Context context){
		mContext = context;
		new Thread(new Runnable() {
			public void run() {
				Looper.prepare();
				mToastHandler = new Handler(){
					@Override
					public void handleMessage(Message msg) {
						// TODO Auto-generated method stub
						super.handleMessage(msg);
						Bundle b = msg.getData();
						String str=b.getString("toast");
						Toast.makeText(mContext, str, Toast.LENGTH_SHORT).show();
					}
					
				};
				Looper.loop();
			}
		}).start();
		
	}
	
	public void Show(String str){
		Message msg= mToastHandler.obtainMessage();
		Bundle bundle = new Bundle();
		bundle.putString("toast", str);
		msg.setData(bundle);
		msg.sendToTarget();
	}
	
}
