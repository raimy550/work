/** Automatically generated file. DO NOT MODIFY */
package com.example.peripheraltest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}